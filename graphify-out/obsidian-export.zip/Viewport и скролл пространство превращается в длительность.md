---
source_file: "docs/lectures/1.1.txt"
type: "concept"
community: "Журнал решений"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Журнал_решений
---

# Viewport и скролл: пространство превращается в длительность

## Connections
- [[open — «Далеко собрались»  дата (счётчик 17 октября 2026 → около 4000 г. до н. э.)]] - `rationale_for` [EXTRACTED]
- [[Лекция 1.1. Лонгрид как особый медиум]] - `references` [EXTRACTED]
- [[Пять свойств браузера скролл, подстройка, ссылка, отклик, жизнь после публикации]] - `references` [EXTRACTED]
- [[Свиток последовательность и жест разворачивания]] - `conceptually_related_to` [EXTRACTED]
- [[Хронотоп (Бахтин) участок со случайной длительностью]] - `conceptually_related_to` [EXTRACTED]
- [[Экран дат «Сегодня» прокручивается барабаном в «около 4000 г. до н. э.»]] - `implements` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Журнал_решений