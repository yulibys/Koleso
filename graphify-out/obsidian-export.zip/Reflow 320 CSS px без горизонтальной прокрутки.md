---
source_file: "docs/lectures/1.5.txt"
type: "rationale"
community: "Сетки и модуль (1.5)"
tags:
  - graphify/rationale
  - graphify/INFERRED
  - community/Сетки_и_модуль_15
---

# Reflow: 320 CSS px без горизонтальной прокрутки

## Connections
- [[Лекция 1.5. Модульные системы и сетки]] - `references` [EXTRACTED]
- [[Отступы шагом 8 px; проверка 320 px и масштаба 200%]] - `semantically_similar_to` [INFERRED]

#graphify/rationale #graphify/INFERRED #community/Сетки_и_модуль_15