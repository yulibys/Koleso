---
source_file: "src/scenery.js"
type: "code"
community: "Пейзажи (scenery.js)"
location: "L11"
tags:
  - graphify/code
  - graphify/EXTRACTED
  - community/Пейзажи_sceneryjs
---

# oak()

## Connections
- [[hero()]] - `calls` [EXTRACTED]
- [[lab()]] - `calls` [EXTRACTED]
- [[parade()]] - `calls` [EXTRACTED]
- [[scenery.js]] - `contains` [EXTRACTED]

#graphify/code #graphify/EXTRACTED #community/Пейзажи_sceneryjs